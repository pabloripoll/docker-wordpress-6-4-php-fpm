<?= $this->private(); ?>

<h6 class="text-center">example <b>tab</b> content</h6>