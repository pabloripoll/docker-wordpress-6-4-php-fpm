<?php

/*
Plugin Name: Api Custom Plugin
Plugin URI: https://github.com/pabloripoll/plugin...
Description: Wordpress plugin to connect to API endpoint

Version: 1.1.0
Requires at least: 4.7

WC requires at least: 2.2.0
WC tested up to: 4.3.2

Author: Pablo Ripoll
Author URI: https://github.com/pabloripoll

Text Domain: ApiCustomPlugin
Domain Path: /languages/

License: GPLv2
*/

if (! defined('ABSPATH')) exit; // exit if this plugin was accessed directly to admin

require_once plugin_dir_path(__FILE__).'autoloader.php';

ApiCustomPluginAutoloader::_instance();

use ApiCustomPlugin\Config\ApiCustomPlugin;
use ApiCustomPlugin\Model\SetupApiCustomPluginModel;

/**
 * Api Custom Plugin plugin functions
 */
function installSettings() {
    SetupApiCustomPluginModel::install();
}

function uninstallSettings() {
    SetupApiCustomPluginModel::uninstall();
}

// WooCommerce
function stockUpdateFromOrderPlaced($order){
    ApiCustomPlugin::wcStockUpdateFromOrder($order, 'decrease');
}

function stockUpdateFromOrderChanged($order_id, $old_state, $new_state) {
    if ($new_state == 'cancelled' || $new_state == 'failed') ApiCustomPlugin::wcStockUpdateFromOrder($order_id, 'increase');
}

function stockUpdateFromProduct($product) {
    $itemChange = $product->get_changes();
    // Prevent loop from WC REST API to send feedback origin and so on infinitely
    if (isset($itemChange['shipping_class_id'])) {
        ApiCustomPlugin::wcStockUpdateFromProduct($product);
    }
}

/**
 * HOOKS
 */

// WordPress
register_activation_hook(__FILE__, 'installSettings');
register_uninstall_hook(__FILE__, 'uninstallSettings');

// WooCommerce

/**
 * Api Custom Plugin plugin
 */
new ApiCustomPlugin(__FILE__);