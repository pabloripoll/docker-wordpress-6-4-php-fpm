<?php

/**
 * ApiCustomPlugin Class Autoloader.
 *
 * @package ApiCustomPlugin
 * @since 1.0.0
 */

class ApiCustomPluginAutoloader
{
    /**
     * Singleton.
     *
     * @since 1.0.0
     * @var ApiCustomPluginAutoloader - Single instance.
     */
    private static $_instance = null;

    /**
     * Private Construct.
     *
     * @package ApiCustomPlugin
     * @since 1.0.0
     */
    private function __construct()
    {
        spl_autoload_register(array($this, 'load'));
    }

    /**
     * Singleton method.
     *
     * @package ApiCustomPlugin
     * @since 1.0.0
     */
    public static function _instance()
    {
        return self::$_instance ? self::$_instance : new ApiCustomPluginAutoloader;
    }

    /**
     * Class Loader.
     *
     * @package ApiCustomPlugin
     * @since 1.0.0
     *
     * @param string $class_name - Class name to load.
     * @return null - Do not return anything.
     */
    public function load($class_name)
    {
        $class_name = str_replace('ApiCustomPlugin\\', '', $class_name);
        $filePath   = str_replace("\\", "/", $class_name);
        $expPath    = array_reverse(explode('/', $filePath));
        $path       = lcfirst($expPath[1]);
        $file       = $expPath[0];

        if (is_readable(trailingslashit(plugin_dir_path(__FILE__).$path).$file.'.php')) {
            include_once trailingslashit(plugin_dir_path(__FILE__).$path).$file.'.php';
        }

        return;
    }

}
