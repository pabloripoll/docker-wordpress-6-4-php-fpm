<?php

namespace ApiCustomPlugin\Controller;

/**
 * ApiCustomPlugin
 *
 * @package ApiCustomPlugin
 * @author Pablo Ripoll
 */

use ApiCustomPlugin\Support\Log;
use ApiCustomPlugin\Support\View;
use ApiCustomPlugin\Config\ApiCustomPlugin;
use ApiCustomPlugin\Model\AdminApiCustomPluginModel;

/**
 * Provides the settings and admin page
 */
class AdminApiCustomPluginController
{
	/**
	 * Plugin.
	 *
	 * @var ApiCustomPlugin
	 */
	protected $plugin;

	/**
	 * Bootstraps the admin part
	 *
	 * @param ApiCustomPlugin $plugin Plugin.
	 */
	public function __construct($plugin)
	{
		$this->plugin = $plugin;

		// Actions
		add_action('init', [$this, 'scriptsHtml']);

		$post = filter_input_array(INPUT_POST);
		if ($post['request'] == 'ajax_call') {
			$action		= $post['action'];
			$response 	= $this->$action();
			echo json_encode($response, 200);
			die;
		} else {
			add_action('admin_menu', [$this, 'admin_menu']);
		}
	}

	/**
	 * UI scripts
	 */
	public function scriptsHtml()
	{
		$assets = $this->plugin->url.'view/assets';
		/* wp_register_style('cg_fontawesome.css', $assets.'/css/fontawesome.min.css');
		wp_enqueue_style('cg_fontawesome.css');
		wp_register_script( 'cg_fontawesome.js', $assets.'/js/fontawesome.min.js','','1.0',true);
		wp_enqueue_script('cg_fontawesome.js'); */
	}

	/**
	 * UI menu
	 */
	public function admin_menu()
	{
		add_menu_page(
			'Administracion de Stock', // page_title
			'Api Custom Plugin', // menu_title
			'manage_options', // capability
			$this->plugin->slug, // menu_slug
			[$this, 'admin_page'], // function
			'dashicons-cloud', // menu icon
			6 // menu position
		);
	}

	public function pluginDir()
	{
		return plugin_dir_path($this->plugin->dir).'ApiCustomPlugin/';
	}

	public function pluginUrl()
	{
		return plugin_dir_url($this->plugin->slug).'ApiCustomPlugin/';
	}

	/**
	 * Set view resource
	 */
	public function view()
	{
		return new View;
	}

	/**
	 * Admin page controller
	 */
	public function admin_page()
	{
		$data = new \stdClass;
		$data->pluginDir = $this->pluginDir();
		$data->pluginUrl = $this->pluginUrl();

		$data->current_tab = filter_input(INPUT_GET, 'tab', FILTER_SANITIZE_STRING);
		$data->current_tab = empty($data->current_tab) ? 'history' : $data->current_tab;

		if ($data->current_tab == 'history') {
			$data->db = $this->getActionsHistory();
		} elseif($data->current_tab == 'config') {
			$data->db = $this->getApiConnectionData();
		}

		View::resource('admin.template', $data);
	}

	/**
	 * History Page
	 *
	 * Plugin actions history list
	 *
	 * @return array
	 */
	public function getActionsHistory($page=1, $listing=20)
    {
		$data = new \stdClass;

		$totalHistoryRows = AdminApiCustomPluginModel::DB()->countActionsHistory();
        $pages = ceil($totalHistoryRows / $listing);

		$getPage = filter_input(INPUT_POST, 'page', FILTER_SANITIZE_STRING);
        $page = !is_numeric($getPage) || $getPage <= 0 ? 1 : $getPage;
        $page = $page > $pages ? 1 : $page;

        $list = AdminApiCustomPluginModel::DB()->queryLimit($page, $listing);
        $historyActions = AdminApiCustomPluginModel::DB()->getActionsHistory($list);

		$data->historyRows 	= $totalHistoryRows;
        $data->total		= $totalHistoryRows;
        $data->page			= $page;
        $data->pages 		= $pages;
        $data->registers 	= $historyActions;

        return $data;
	}

	/**
	 * Config Page
	 *
	 * Get Api Custom Plugin API connection data
	 *
	 * @return array
	 */
	public function getApiConnectionData()
    {
		$data = new \stdClass;
		$data->historyRows 	= AdminApiCustomPluginModel::DB()->countActionsHistory();
		$data->api			= AdminApiCustomPluginModel::DB()->getApiData();
		$data->woocommerce	= AdminApiCustomPluginModel::DB()->getWooCommerceKeys();
		$data->warehouses	= AdminApiCustomPluginModel::DB()->getWarehouses();

		return $data;
	}

	/**
	 * Config Page
	 *
	 * Set Api Custom Plugin API connection data
	 *
	 * @return null
	 */
	public function setApiConnectionData()
    {
        $warehouses = [];
        if (! empty($_POST['CGAPI_WAREHOUSESJSON'])) {
            $objects = json_decode($_POST['CGAPI_WAREHOUSESJSON'], true);
            foreach ($objects as $row) {
                $warehouses[] = ['warehouse' => $row['IdAlmacen'], 'name' => $row['Descripcion']];
            }
        }

        $apiData = new \stdClass;
        $apiData->Name       = $_POST['CGAPI_NAME'];
        $apiData->EndPoint   = $_POST['CGAPI_ENDPOINT'];
        $apiData->Key        = $_POST['CGAPI_KEY'];
        $apiData->User       = $_POST['CGAPI_USER'];
        $apiData->Warehouses = $warehouses;
		$save = AdminApiCustomPluginModel::DB()->setApiData($apiData);
        if ($save) {
            $history = new \stdClass;
            $history->reference		= 'module';
            $history->action		= 'actualizacion';
            $history->description	= 'Se actualiz&oacute; par&aacute;metros de conexi&oacute;n';
            AdminApiCustomPluginModel::DB()->setActionHistory($history);

            $history->reference		= 'module';
            $history->action		= 'actualizacion';
            $history->description	= 'Se actualiz&oacute; el listado de almacenes';
            AdminApiCustomPluginModel::DB()->setActionHistory($history);

            return [
                'process'   => true,
                'almacenes' => $apiData->Warehouses
            ];
        } else {
            return ['process' => false];
        }
	}

	/**
	 * Config Page
	 *
	 * Get Api Custom Plugin API data transfer configuration
	 *
	 * @return array
	 */
	public function getApiConnectionConfig()
    {
        $api        = AdminApiCustomPluginModel::DB()->getApiData();
        $warehouse  = empty($api['warehouse']) ? '' : $api['warehouse'];
        $wp_ref     = empty($api['wp_ref']) ? '' : $api['wp_ref'];
        $cg_ref     = empty($api['cg_ref']) ? '' : $api['cg_ref'];
		$wp_adj     = empty($api['wp_adj']) ? '' : $api['wp_adj'];

        $warehouses = [];
        $dbWarehouses = AdminApiCustomPluginModel::DB()->getWarehouses();
        if (!empty($dbWarehouses)) {
            foreach ($dbWarehouses as $row) {
                $warehouses[] = ['warehouse' => $row['IdAlmacen'], 'name' => $row['Descripcion']];
            }
        }

        $data = [
            'stock'     => $warehouse,
            'warehouses'=> $warehouses,
            'wp_ref'    => $wp_ref,
            'cg_ref'    => $cg_ref,
			'wp_adj'    => $wp_adj,
        ];

        return $data;
	}

    /**
	 * Config Page
	 *
	 * Set Api Custom Plugin API data transfer configuration
	 *
	 * @return bool
	 */
	public function setApiConnectionConfig()
    {
        $apiConfig = new \stdClass;
        $apiConfig->Stock   = $_POST['CGAPI_STOCK'];
        $apiConfig->WP_Ref  = $_POST['CGAPI_WP_REF'];
        $apiConfig->Cg_Ref  = $_POST['CGAPI_CG_REF'];
		$apiConfig->WP_Adj  = $_POST['CGAPI_WP_ADJ'];
		$save = AdminApiCustomPluginModel::DB()->setConnectionConfig($apiConfig);
        if ($save) {

            $history = new \stdClass;
            $history->reference		= 'module';
            $history->action		= 'configuraci&oacute;n';
            $history->description	= 'Se actualiz&oacute; par&aacute;metros de configuraci&oacute;n';
            AdminApiCustomPluginModel::DB()->setActionHistory($history);

            return true;
        }
        return false;
	}

	/**
	 * WooCommerce stock adjust inform
	 *
	 * Get Config to informe Api Custom Plugin API
	 *
	 * @return array
	 */
	public function getWooCommerceStockAdjust()
    {
        $api        = AdminApiCustomPluginModel::DB()->getApiData();
		$wp_adj     = empty($api['wp_adj']) ? '' : $api['wp_adj'];

        $data = [
			'wp_adj'    => $wp_adj,
        ];

        return $data;
	}

	/**
	 * Get Products from Api Custom Plugin
	 *
	 * @return array
	 */
	public function getProductsFromApiCustomPlugin()
    {
        $api        = AdminApiCustomPluginModel::DB()->getApiData();
        $endpoint  	= $api->endpoint;
        $apikey     = $api->apikey;
        $user     	= $api->user;
		$cgwh_id 	= $api->warehouse;
		$wp_ref     = $api->wp_ref;
        $cg_ref     = $api->cg_ref;
		$warehouse  = $cgwh_id == 0 ? [] : (array) AdminApiCustomPluginModel::DB()->getWarehouse($cgwh_id);

        $connection = [
            'endpoint'  => $endpoint,
            'apikey'	=> $apikey,
            'user'		=> $user,
            'cgwh_id'	=> $cgwh_id,
            'wp_ref'    => $wp_ref,
            'cg_ref'    => $cg_ref,
			'warehouse' => $warehouse,
        ];

		$error = 0;
		$field = [];
		foreach ($connection as $key => $value) {
			if (empty($value)) {
				$error++;
				$field[] = $key;
			}
		}
		$status = $error == 0 ? true : false;

		$products = $status == false ? '' : AdminApiCustomPluginModel::DB()->getWooCommerceProducts(['product_id', $wp_ref]); // selected cols in array is mandatory

		$data = [
			'status'	=> $status,
			'connection'=> $connection,
			'products'	=> $products
		];

        return $data;
	}

	/**
	 * Update Products Stock Quantity from Api Custom Plugin
	 *
	 * @return array
	 */
	public function updateProductStockFromApiCustomPlugin()
    {
        $product_id = $_POST['product_id'];
        $new_stock_quantity = $_POST['new_stock_quantity'];

		$product = AdminApiCustomPluginModel::DB()->getWooCommerceProduct($product_id, ['stock_quantity']);
		$data = [
			'product_id'	=> $product_id,
			'old_stock_quantity'=> $product->stock_quantity,
			'new_stock_quantity'=> $new_stock_quantity
		];
		AdminApiCustomPluginModel::DB()->updateProductStockFromApiCustomPlugin($data);

        return $data;
	}

	/**
	 * Create hHistory Register of Products Stock Quantity Update from Api Custom Plugin
	 *
	 * @return array
	 */
	public function historyProductStockFromApiCustomPlugin()
    {
        $related = $_POST['related'];
		$relText = $related == 1 ? 'producto' : 'productos';

        $history = new \stdClass;
		$history->reference		= 'products';
		$history->action		= 'stock multiple';
		$history->description	= "Se actualiz&oacute; el stock de $related $relText con el stock en almac&eacute;n de Api Custom Plugin";
		AdminApiCustomPluginModel::DB()->setActionHistory($history);

        return (array) $history;
	}

}
