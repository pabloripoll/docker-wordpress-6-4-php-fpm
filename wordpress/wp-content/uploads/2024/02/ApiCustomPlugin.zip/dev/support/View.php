<?php
namespace ApiCustomPlugin\Support;

/**
 * ApiCustomPlugin
 *
 * @package ApiCustomPlugin
 * @author Pablo Ripoll
 */

use ApiCustomPlugin\Support\Log;

class View
{
    /**
     * Create a view from resource file.
     *
     * @param  string  $view
     * @param  mixed  $data
     *
     * @return html
     */
    public static function resource($view = null, $data = null)
    {
        $view = str_replace('.php', '', $view);
        $view = (str_replace('.', '/', $view)).'.php';
        $file = dirname(__DIR__, 1) . '/view/'.$view;

        if ( file_exists($file) ) :
            ob_start();
            include_once $file;
            echo ob_get_clean();
        else :
            Log::Debug($view . ' resource file not found');
        endif;
    }

}