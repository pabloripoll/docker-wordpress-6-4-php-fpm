<?php

if (! defined('ABSPATH')) exit;

?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<div class="wrap">
    <h1 class="wp-heading-inline">Api Custom Plugin</h1>

    <img class="img-fluid" src="<?= $data->pluginUrl; ?>view/assets/img/banner_pabloripoll.jpg" alt="Plugin Api Custom Plugin" style="border:1px solid #AEAEAE;">

    <ul class="subsubsub">
        <li class="all">
            <?php $active = $data->current_tab != 'history' ? '' : 'current'; ?>
            <a href="admin.php?page=ApiCustomPlugin&tab=history" class="<?= $active; ?>" aria-current="page">Historial <span class="count">(<?= $data->db->historyRows; ?>)</span></a> |
        </li>
        <li class="publish">
            <?php $active = $data->current_tab != 'config' ? '' : 'current'; ?>
            <a href="admin.php?page=ApiCustomPlugin&tab=config" class="<?= $active; ?>">Configuración <span class="count"></span></a>
        </li>
    </ul>

    <div id="ApiCustomPlugin-content">
        <?php
        if ($data->current_tab == 'history') :
            include $data->pluginDir.'/view/admin/tabs/history.php';
        elseif ($data->current_tab == 'config') :
            include $data->pluginDir.'/view/admin/tabs/config.php';
        endif;
        ?>
    </div>

    <!-- JQuery 3.6.0 -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <!-- Optional JavaScript; choose one of the two! -->
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
    <!-- Custom JS -->
    <script>
    // Form URL
    const formUrl   = 'admin.php?page=ApiCustomPlugin';

    // HISTORY
    var historyListPage = '1',
    historyListPages	= '<?= (isset($data->db->pages) ? $data->db->pages : null); ?>',
    historyListTotal 	= '<?= (isset($data->db->total) ? $data->db->total : null); ?>';

    // API Connection Data Object
    var apiData = {
        'Name' 		: '',
        'EndPoint' 	: '',
        'Key' 		: '',
        'User' 		: 0
    };
    var savedApiData = {
        'Name' 		: '<?= (isset($data->db->api) ? $data->db->api->name : null); ?>',
        'EndPoint' 	: '<?= (isset($data->db->api) ? $data->db->api->endpoint : null); ?>',
        'Key' 		: '<?= (isset($data->db->api) ? $data->db->api->key : null); ?>',
        'User' 		: '<?= (isset($data->db->api) ? $data->db->api->user : null); ?>'
    };

    // FEATURES
    function progressBar(element) {
        $(element).animate({
            width: "0%"
        }, 1)
        $(element).each(function() {
            var elem = $(this);
            var perc = elem.attr("data-percentage");
            var current_perc = 0;
            var progress = setInterval(function() {
                if (current_perc >= perc) {
                    clearInterval(progress);
                } else {
                    current_perc += 1;
                    if (current_perc <= 100) { elem.css('width', (current_perc)+'%') };
                }
                if (current_perc <= 100){ elem.text((current_perc)+'%') };
            }, 100);
        })
    }

    // History
    function loadingHistoryTable() {
        var tableLoading = '<tr><td align="center" colspan="6">Aguarda por favor... <i class="fa fa-spinner fa-spin"></i></td></tr>';
        $('#cloud-gestion-history-table-body').html(tableLoading)
    }

    function loadHistoryTable(page=1) {
        loadingHistoryTable()
        var formData = new FormData();
        formData.append('page', page)
        formData.append('action', 'getActionsHistory') // mandatory
        formData.append('request', 'ajax_call') // mandatory
        $.ajax({
            url: formUrl,
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            type: 'POST',
            error : function (error) { console.log(error) },
            success: function (response) {
                var data = JSON.parse(response);
                historyListPage	= data.page
                historyListPages= data.pages
                historyListTotal= data.total
                $('.cloud-gestion-history-page').html(data.page)

                var i = 0;
                var rows = '';
                data.registers.forEach(action => {
                    i++
                    var trClass = '';
                    if (i % 2 != 0) trClass = 'alternate'
                    var row = '<tr class="'+ trClass +'">';
                    row += '<td>' + action.updated_at + '</td>'
                    row += '<td>' + action.action + '</td>'
                    row += '<td>' + action.description + '</td>'
                    if (action.quantity == 0) {
                        row += '<td></td>'
                        row += '<td></td>'
                        row += '<td></td>'
                    } else {
                        row += '<td align="right">' + action.stock + '</td>'
                        row += '<td align="right">' + action.quantity + '</td>'
                        row += '<td align="right">' + action.stock_update + '</td>'
                    }
                    row += '<td><a href="/wp-admin/post.php?post=' + action.id_product + '" target="_blank">' + action.name + '</td>'
                    row += '</tr>'
                    rows += row
                })
                $('#cloud-gestion-history-table-body').html(rows)
            }
        })
    }

    function ApiCustomPluginHistoryPrev() {
        var page = historyListPage;
        console.log(`actual page: ${page}`)
        if (historyListPage > 1) {
            page = parseInt(page) - 1;
            console.log(`request page: ${page}`)
            loadHistoryTable(page)
        }
    }

    function ApiCustomPluginHistoryNext() {
        var page = historyListPage;
        console.log(`actual page: ${page}`)
        if (historyListPage < historyListPages) {
            page = parseInt(page) + 1;
            console.log(`request page: ${page}`)
            loadHistoryTable(page)
        }
    }

    // ASYNC functions
    $(document).ready(function(){

        // History
        $(document).on('classAdded', '#tab-actions', function (e, className) {
            if (className == "active") { loadHistoryTable() }
            e.preventDefault();
        })

    })

    // CONFIG
    function fillApiData() {
        apiData.Name 		= $('#CGAPI_NAME').val()
        apiData.EndPoint 	= $('#CGAPI_ENDPOINT').val()
        apiData.Key 		= $('#CGAPI_KEY').val()
        apiData.User 		= $('#CGAPI_USER').val()
    }

    function fillStoresStockSelect(stores) {
        var options = '<option value="">- selecciona almacén -</option>';
        stores.forEach(store => { options += '<option value="'+store.warehouse+'">'+store.name+'</option>' })
        $('#CGAPI_STOCK').html(options)
    }

    function setApiCustomPluginConnection() {
        $.ajaxSetup({ beforeSend: function(xhr) { xhr.setRequestHeader('Authorization', apiData.Key); xhr.setRequestHeader('IdUsuario', apiData.User) }})
    }

    function checkConnectionParamsAlert(process, field=null, status, msg) {
        var alert = '', state = 'danger';
        if (process == 'connection') {
            if (msg == 'processing') {
                $('#api-connection-check-status').css('display', 'none')
                $('#api-connection-check-bar').css('display', 'block')
                progressBar('#api-connection-bar')
            } else {
                $('#api-connection-check-bar').css('display', 'none')
                $('#api-connection-check-status').css('display', 'block')
                if (status == true) state = 'success'
                alert = '<div class="alert alert-'+ state +'">'+ msg +'</div>'
                $('#api-connection-check-status').html(alert)
            }
        } else if (process == 'form' && status == false) {
            $('#' + field + '_alert').html(msg)
            $('#' + field + '_alert').addClass('text-'+ state)
        }
    }

    function checkApiConnectionParams() {
        var process = 'form', field = '', status = false, msg = '';
        if ($('#CGAPI_NAME').val() == '') {
            field = 'CGAPI_NAME'; msg = 'El nombre debe ser mayor a 3 caracteres.'
            checkConnectionParamsAlert(process, field, status, msg)
            return false
        } else if ($('#CGAPI_ENDPOINT').val() == '') {
            field = 'CGAPI_ENDPOINT'; msg = 'Complete la URL de conexión.'
            checkConnectionParamsAlert(process, field, status, msg)
            return false
        } else if ($('#CGAPI_KEY').val() == '') {
            field = 'CGAPI_KEY'; msg = 'La longitud de la clave no es correcta.'
            checkConnectionParamsAlert(process, field, status, msg)
            return false
        } else if ($('#CGAPI_USER').val() == '' || $('#CGAPI_USER').val() == 0) {
            field = 'CGAPI_USER'; msg = 'El usuario debe ser un dígito mayor a cero.'
            checkConnectionParamsAlert(process, field, status, msg)
            return false
        } else {
            return true;
        }
    }

    function saveApiConnectionDataAbort() {
        $('#api-connection-check-status').css('display', 'none')
        $('#api-connection-check-btn').css('display', 'block')
        $('#api-connection-check-save-btns div').html('')
        $('#CGAPI_NAME').val(savedApiData.Name)
        $('#CGAPI_ENDPOINT').val(savedApiData.EndPoint)
        $('#CGAPI_KEY').val(savedApiData.Key)
        $('#CGAPI_USER').val(savedApiData.User)
        $('#CGAPI_NAME_alert').html('')
        $('#CGAPI_ENDPOINT_alert').html('')
        $('#CGAPI_KEY_alert').html('')
        $('#CGAPI_USER_alert').html('')
    }

    function saveApiConnectionDataButtons() {
        return  '<button type="button" id="api-connection-cancel-btn" class="btn btn-secondary">Cancelar</button>' +
                '<button type="button" id="api-connection-update-btn" class="btn btn-primary float-end">Guardar Datos</button>';
    }
    function saveApiConnectionDataButtonsProcess() {
        return '<button type="button" class="btn btn-primary float-end"><i class="fa fa-spinner fa-spin"></i></button>';
    }

    function apiConnectionCheck() {
        var check = checkApiConnectionParams();
        if (check == true) {
            $('#api-connection-check-btn').css('display', 'none')
            checkConnectionParamsAlert('connection', 'check', null, 'processing')
            fillApiData() // New api params data
            setApiCustomPluginConnection() // jQuery conection set
            $.ajax({
                type: "GET",
                url: apiData.EndPoint + '/usuarios/' + apiData.User,
                contentType: "application/json",
                dataType: "json",
                /* beforeSend: function() { // Do not use this property because is used in setApiCustomPluginConnection() }, */
                error: function(error) {
                    checkConnectionParamsAlert('connection', 'check', false, 'error de conexión en ' + apiData.EndPoint + '/usuarios/' + apiData.User)
                    console.log(error)
                    $('#api-connection-check-btn').css('display', 'block')
                },
                success: function(response) {
                    (async () => {
                        setApiCustomPluginConnection()
                        $.ajax({
                            url: apiData.EndPoint + '/almacen',
                            type: "GET", contentType: "application/json", dataType: "json",
                            error: function(error) { console.log('Error de conexión en '+ apiData.EndPoint + '/almacen') },
                            success: function(response) { $('#CGAPI_WAREHOUSESJSON').val(JSON.stringify(response)) }
                        })
                    })();
                    var response = response[0];
                     window.setTimeout(function() { // lets bar animate
                        checkConnectionParamsAlert('connection', 'check', true, 'Conexión exitosa con la aplicación ' + apiData.Name)
                        $('#api-connection-check-save-btns div').html(saveApiConnectionDataButtons())
                    }, 3000) // lets bar animate
                }
            })
        }
    }

    function saveApiConnectionData() {
        var check = checkApiConnectionParams();
        if (check == true) {
            $('#api-connection-check-save-btns div').html(saveApiConnectionDataButtonsProcess())
            var formData = new FormData();
            formData.append('CGAPI_NAME', $('#CGAPI_NAME').val())
            formData.append('CGAPI_ENDPOINT', $('#CGAPI_ENDPOINT').val())
            formData.append('CGAPI_KEY', $('#CGAPI_KEY').val())
            formData.append('CGAPI_USER', $('#CGAPI_USER').val())
            formData.append('CGAPI_WAREHOUSESJSON', $('#CGAPI_WAREHOUSESJSON').val())
            formData.append('action', 'setApiConnectionData') // mandatory
            formData.append('request', 'ajax_call') // mandatory
            $.ajax({
                url: formUrl,
                data: formData,
                cache: false,
                processData: false,
                contentType: false,
                type: 'POST',
                error : function (error) {
                    checkConnectionParamsAlert('response', false, 'response', 'Error al guardar datos en base de datos.')
                    $('#api-connection-check-save-btns div').html(saveApiConnectionDataButtons())
                },
                success: function (response) {
                    var data = JSON.parse(response);
                    if (data.process == true) {
                        $('#api-connection-check-status').css('display', 'none')
                        $('#api-connection-check-btn').css('display', 'block')
                        $('#api-connection-check-save-btns div').html('')
                        fillStoresStockSelect(data.almacenes)
                        var btn = document.getElementById('api-connection-check-btn');
                        btn.innerHTML = '<i class="fa fa-check"></i>&nbsp;Guardado'
                        btn.classList.remove('btn-primary')
                        btn.classList.add('btn-success')
                        setTimeout(function(){
                            btn.innerHTML = 'Comprobar Conexión'
                            btn.classList.remove('btn-success')
                            btn.classList.add('btn-primary')
                        }, 3000);
                    }
                }
            })
        }
    }

    // CONFIG
    function checkConfigAlert(field, status, msg) {
        var alert = '';
        if (status == false) {
            $('#' + field + '_alert').html(msg)
            $('#' + field + '_alert').addClass('text-danger')
        }
    }

    function checkConfig() {
        var field = '', status = false, msg = '';
        var stock 	= $('#CGAPI_STOCK').val(),
        wp_ref		= $('#CGAPI_WP_REF').val(),
        cg_ref		= $('#CGAPI_CG_REF').val(),
        wp_adj		= $('#CGAPI_WP_ADJ').val();
        if (stock == '' || stock == null) {
            field = 'CGAPI_STOCK'; msg = 'Seleccione un almacén de ApiCustomPlugin.'
            checkConfigAlert(field, status, msg); return false
        } else if (wp_ref == '' || wp_ref == null) {
            field = 'CGAPI_WP_REF'; msg = 'Seleccione la referencia de WordPress / WooCommerce.'
            checkConfigAlert(field, status, msg); return false
        } else if (cg_ref == '' || cg_ref == null) {
            field = 'CGAPI_CG_REF'; msg = 'Seleccione la referencia de ApiCustomPlugin.'
            checkConfigAlert(field, status, msg); return false
        } else {
            return true
        }
    }

    function saveApiConnectionConfigButtonsProcess() {
        return '<button type="button" class="btn btn-success float-end"><i class="fa fa-spinner fa-spin"></i></button>';
    }

    function saveApiConnectionConfigButtons() {
        return '<button type="button" id="api-connection-config-btn" class="btn btn-primary float-end">Guardar</button>';
    }

    function saveApiConnectionConfig() {
        var check = checkConfig();
        if (check == true) {
            $('#api-connection-config-btns-wrapper').html(saveApiConnectionConfigButtonsProcess())
            var formData = new FormData();
            formData.append('CGAPI_STOCK', $('#CGAPI_STOCK').val())
            formData.append('CGAPI_WP_REF', $('#CGAPI_WP_REF').val())
            formData.append('CGAPI_CG_REF', $('#CGAPI_CG_REF').val())
            formData.append('CGAPI_WP_ADJ', $('#CGAPI_WP_ADJ').val())
            formData.append('action', 'setApiConnectionConfig') // mandatory
            formData.append('request', 'ajax_call') // mandatory
            $.ajax({
                url: formUrl,
                data: formData,
                cache: false,
                processData: false,
                contentType: false,
                type: 'POST',
                error: function(error) {
                    $('#api-connection-config-btns-wrapper').html(saveApiConnectionConfigButtons())
                },
                success: function (response) {
                    $('#api-connection-config-btns-wrapper').html(saveApiConnectionConfigButtons())
                    var btn = document.getElementById('api-connection-config-btn');
                    btn.innerHTML = '<i class="fa fa-check"></i>&nbsp;Guardado'
                    btn.classList.remove('btn-primary')
                    btn.classList.add('btn-success')
                    setTimeout(function(){
                        btn.innerHTML = 'Guardar'
                        btn.classList.remove('btn-success')
                        btn.classList.add('btn-primary')
                    }, 3000);
                }
            })
        }
    }

    // STOCK
    function getProductsStockFromApiCustomPlugin(connection) {
        (async () => {

        })();
    }

    function updateProductsFromApiCustomPlugin() {

        $('#api-update-stock-status').html(`<div class="alert alert-warning">Preparando la actualización</div>`)
        $('#api-update-stock-status').css('display', 'block')
        $('#api-update-stock-bar-wrapper').css('display', 'block')
        $('#api-update-stock-btn').css('display', 'none')

        var connection  = '';
        var products    = '';
        var totalProducts = 0;
        var formData = new FormData();
        formData.append('action', 'getProductsFromApiCustomPlugin') // mandatory
        formData.append('request', 'ajax_call') // mandatory
        $.ajax({
            url: formUrl,
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            type: 'POST',
            error: function(error) {
                $('#api-update-stock-status').html(`<div class="alert alert-danger">Error de script.</div>`)
                $('#api-update-stock-bar-wrapper').css('display', 'none')
                $('#api-update-stock-btn').css('display', 'block')
            },
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status == false) {
                    var text = `No se puede realizar la conexión con la API de Api Custom Plugin. Revise los parámetros de la conexión.`;
                    $('#api-update-stock-status').html(`<div class="alert alert-danger">${text}</div>`)
                    $('#api-update-stock-bar-wrapper').css('display', 'none')
                    $('#api-update-stock-btn').css('display', 'block')
                } else {
                    connection  = data.connection;
                    products    = data.products;
                    totalProducts = products.length;
                    var text = `Conectando con aplicación de Api Custom Plugin. Total de productos ${totalProducts}`;
                    $('#api-update-stock-bar').css('width', '25%')
                    $('#api-update-stock-bar').html('procesando...')
                    $('#api-update-stock-status').html(`<div class="alert alert-info">${text}</div>`)
                }
            }
        }).then(function() {
            $.ajaxSetup({
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('Authorization', connection.apikey);
                    xhr.setRequestHeader('IdUsuario', connection.user)
                }
            })
            var related = 0;
            var processed = 0;
            Object.entries(products).forEach(([key, product]) => {

                var cg_ref  = connection.cg_ref;
                var wp_ref  = connection.wp_ref;

                var perc = (75 * (100 / parseInt(totalProducts)) / 100);
                var barWidth = parseFloat($('#api-update-stock-bar')[0].style.width);
                var newBarWidth = barWidth + perc;
                $('#api-update-stock-bar').css('width', newBarWidth+'%')
                $('#api-update-stock-status').html(`<div class="alert alert-info">Obteniendo información de aplicación de Api Custom Plugin. Producto <span id="stock-processed">${processed}</span> / ${totalProducts}</div>`)

                if (product[wp_ref] == '') {
                    processed++;
                    $('#api-update-stock-bar').html(`producto no contabiliza`)
                } else {
                    $('#api-update-stock-bar').html(`procesando producto ${wp_ref} ${product[wp_ref]}`)
                    var query   = `${connection.cg_ref}='${product[wp_ref]}'`;
                    query = btoa(query);
                    $.ajax({
                        type: "GET",
                        url: connection.endpoint + '/conceptos/' + query,
                        contentType: "application/json",
                        dataType: "json",
                        error: function(error) {
                            $('#api-update-stock-bar').html(`producto ${wp_ref} ${product[wp_ref]} - No existe en Api Custom Plugin.`)
                            //console.log(error)
                        },
                        success: function(response) {
                            $('#api-update-stock-bar').html(`producto ${wp_ref} ${product[wp_ref]} - Obteniendo stock.`)
                            concept = response[0];
                            query = `IdTarifa='${concept.IdTarifa}' AND IdAlmacen='${connection.cgwh_id}'`;
                            query = btoa(query);
                            $.ajax({
                                type: "GET",
                                url: connection.endpoint + '/almacen_stock/' + query,
                                contentType: "application/json",
                                dataType: "json",
                                error: function(error) { console.log(error) },
                                success: function(response) {
                                    var new_stock_quantity = response[0].Stock;
                                    $('#api-update-stock-bar').html(`producto ${wp_ref} ${product[wp_ref]} - IdTarifa=${concept.IdTarifa} / IdAlmacen=${connection.cgwh_id} / Stock=${new_stock_quantity}`)
                                    var formData = new FormData();
                                    formData.append('product_id', product.product_id)
                                    formData.append('new_stock_quantity', new_stock_quantity)
                                    formData.append('action', 'updateProductStockFromApiCustomPlugin') // mandatory
                                    formData.append('request', 'ajax_call') // mandatory
                                    $.ajax({
                                        url: formUrl,
                                        data: formData,
                                        cache: false,
                                        processData: false,
                                        contentType: false,
                                        type: 'POST',
                                        error: function(error) { console.log(error) },
                                        success: function (response) {
                                            var data = JSON.parse(response);
                                            related++;
                                            processed++;
                                            $('#stock-processed').html(processed)
                                            if (processed == totalProducts) {
                                                $('#api-update-stock-bar').html('')
                                                $('#api-update-stock-bar-wrapper').css('display', 'none')
                                                $('#api-update-stock-status').html(`
                                                <div class="alert alert-success">
                                                    Stock actualizado con almacén de aplicación de Api Custom Plugin.<br>
                                                    Productos procesados: <b>${processed}</b><br>
                                                    Productos relacionados: <b>${related}</b>
                                                </div>`)
                                                setTimeout(function(){
                                                    $('#api-update-stock-status').html('')
                                                    $('#api-update-stock-status').attr('class', 'alert alert-success')
                                                    $('#api-update-stock-status').attr('class', 'alert alert-light')
                                                    $('#api-update-stock-status').css('display', 'none')
                                                    $('#api-update-stock-btn').css('display', 'block')
                                                }, 3000);
                                                var formData = new FormData();
                                                formData.append('related', related)
                                                formData.append('action', 'historyProductStockFromApiCustomPlugin') // mandatory
                                                formData.append('request', 'ajax_call') // mandatory
                                                $.ajax({
                                                    url: formUrl,
                                                    data: formData,
                                                    cache: false,
                                                    processData: false,
                                                    contentType: false,
                                                    type: 'POST',
                                                    error: function(error) { console.log(error) },
                                                    success: function (response) {
                                                        console.log(response)
                                                    }
                                                })
                                            }
                                        }
                                    })
                                }
                            })
                        }
                    })
                } // product
            })
        })
    }

    // ASYNC functions
    $(document).ready(function(){

        // API Connection form
        $(document).on('focus', '#CGAPI_NAME', function (e) {
            e.preventDefault(); $('#CGAPI_NAME_alert').attr('class', '')
            $('#CGAPI_NAME_alert').html('Ingresa un nombre descriptivo para identificar la conexión.')
        })
        $(document).on('focus', '#CGAPI_ENDPOINT', function (e) {
            e.preventDefault(); $('#CGAPI_ENDPOINT_alert').attr('class', '')
            $('#CGAPI_ENDPOINT_alert').html('URL común de conexión con aplicación Api Custom Plugin.')
        })
        $(document).on('focus', '#CGAPI_KEY', function (e) {
            e.preventDefault(); $('#CGAPI_KEY_alert').attr('class', '')
            $('#CGAPI_KEY_alert').html('Clave autorizada y cifrada para realizar la conexión.')
        })
        $(document).on('focus', '#CGAPI_USER', function (e) {
            e.preventDefault(); $('#CGAPI_USER_alert').attr('class', '')
            $('#CGAPI_USER_alert').html('ID de usuario en aplicación de ApiCustomPlugin para la conexión.')
        })
        $(document).on('click', '#api-connection-check-btn', function (e) {
            e.preventDefault(); apiConnectionCheck()
        })
        $(document).on('click', '#api-connection-cancel-btn', function (e) {
            e.preventDefault(); saveApiConnectionDataAbort()
        })
        $(document).on('click', '#api-connection-update-btn', function (e) {
            e.preventDefault(); saveApiConnectionData()
        })

        // Api Connection Config
        $(document).on('focus', '#CGAPI_STOCK', function (e) {
            e.preventDefault(); $('#CGAPI_STOCK_alert').attr('class', '')
            $('#CGAPI_STOCK_alert').html('Almacén de aplicación Api Custom Plugin de donde se tomará el stock de los productos que se publiquen en WooCommerce.')
        })
        $(document).on('focus', '#CGAPI_WP_REF', function (e) {
            e.preventDefault(); $('#CGAPI_WP_REF_alert').attr('class', '')
            $('#CGAPI_PS_REF_alert').html('Campo de productos para ralación de WooCommerce con aplicación Api Custom Plugin.')
        })
        $(document).on('focus', '#CGAPI_CG_REF', function (e) {
            e.preventDefault(); $('#CGAPI_CG_REF_alert').attr('class', '')
            $('#CGAPI_CG_REF_alert').html('Campo de productos Api Custom Plugin para ralación en la conexión.')
        })
        $(document).on('click', '#api-connection-config-btn', function (e) {
            e.preventDefault(); saveApiConnectionConfig()
        })

        // Api Stock Update
        $(document).on('click', '#api-update-stock-btn', function (e) {
            e.preventDefault(); updateProductsFromApiCustomPlugin()
        })

    })
    </script>
</div>