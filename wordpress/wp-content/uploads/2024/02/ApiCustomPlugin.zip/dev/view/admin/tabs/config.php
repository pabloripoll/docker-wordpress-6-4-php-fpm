<div id="col-container" class="wp-clearfix mt-5">

    <div id="col-left">
        <div class="col-wrap">
            <div class="form-wrap">
                <h2><mark>Importante:</mark> Actualización de stock en WooCommerce</h2>
                <hr>
                <p>
                    Si deseas corregir el stock de uno ó varios productos manualmente desde WooCommerce pero no desdeas que se sincronice con la App de Api Custom Plugin,
                    revisa que en "<b><i>Configuración de relación entre WooCommerce y Api Custom Plugin</i></b>" el campo "<b><i>Contabilizar Ajuste Manual</i></b>" se encuentre en "No informar ajustes manuales".<br><br>
                    Si no es así, selecciona "No informar ajustes manuales" y guarda los cambios.<br><br>
                    Una vez finalizada la acción, si deseas que los cambios manuales estén sincronizados, vuelve a modificar la configuración.<br><br>
                </p>
                <p>
                    <b>* Recuerda</b> que siempre que desees eliminar una orden de compra del historial de WooCommerce, primero debes cambiar el estado de la orden
                    a <b><i>Cancelado</i></b> para que se sincronice el stock de WooCommerce con el almacén de Api Custom Plugin.<br><br>
                </p>
                <h2>Configuración del plugin</h2>
                <hr>
                <p>
                1) Ingresa los datos de conexión con la API de Api Custom Plugin. Puedes consultar el manual en Ayuda Api Custom Plugin.<br><br>
                2) Luego de realizada la prueba de conexión, guarda los datos para poder obtener el listado de almacenes de tu aplicación.<br><br>
                3) Configura los datos del almacén desde donde se descontará el stock de los productos relacionados entre Api Custom Plugin y WooCommerce.<br><br>
                4) Recuerda revisar los campos de relación entre ambas aplicaciones para que los productos estén en sincronía.<br><br>
                </p>
                <p><strong>En caso de necesitar asistencia técnica para la instalación, visita <a href="https://github.com/pabloripoll/plugin..." target="_blank">Manual eCommerce de Api Custom Plugin</a> para conocer los detalles de la configuración.</strong>
                Si necesitas ayuda para conocer más detalles de éste plugin contacta con nosotros <a href="https://github.com/pabloripollcontacto.html" target="_blank">página de contacto de Código Con Sentido</a> y nos pondremos en contacto contigo para afrecerte ayuda técnica teléfonica.
                </p>
            </div>
        </div>
    </div><!-- /col-left -->

    <div id="col-right">

        <div class="col-wrap">
            <div class="form-wrap">
                <h2><b>Datos de conexión con ERP Api Custom Plugin</b></h2>
                <hr>
                <input type="hidden" id="CGAPI_WAREHOUSESJSON" value="">
                <div class="form-field form-required term-name-wrap">
                    <label for="tag-name"><b>Nombre Aplicación</b></label>
                    <input autocomplete="off" type="text" class="form-control" id="CGAPI_NAME" value="<?= $data->db->api->name; ?>" placeholder="Nombre de la conexión">
                    <p id="CGAPI_NAME_alert">Ingresa un nombre descriptivo para identificar la conexión.</p>
                </div>
                <div class="form-field form-required term-name-wrap">
                    <label for="tag-name"><b>URL Conexión</b></label>
                    <input autocomplete="off" type="text" class="form-control" id="CGAPI_ENDPOINT" value="<?= $data->db->api->endpoint; ?>" placeholder="URL API Api Custom Plugin">
                    <p id="CGAPI_ENDPOINT_alert">URL común de conexión con aplicación Api Custom Plugin.</p>
                </div>
                <div class="form-field form-required term-name-wrap">
                    <label for="tag-name"><b>Clave</b></label>
                    <input autocomplete="off" type="text" class="form-control" id="CGAPI_KEY" value="<?= $data->db->api->apikey; ?>" placeholder="Clave cifrada de conexión">
                    <p id="CGAPI_KEY_alert">Clave autorizada y cifrada para realizar la conexión.</p>
                </div>
                <div class="form-field form-required term-name-wrap">
                    <label for="tag-name"><b>ID Usuario</b></label>
                    <input autocomplete="off" type="text" class="form-control" id="CGAPI_USER" value="<?= $data->db->api->user; ?>" placeholder="ID de usuario de ApiCustomPlugin">
                    <p id="CGAPI_USER_alert">ID de usuario en aplicación de ApiCustomPlugin para la conexión.</p>
                </div>
                <div id="api-connection-check-wrapper" class="d-flex p-0">
                    <div class="col-md-12">
                        <div id="api-connection-check-bar" style="display:none">
                            <div class="progress">
                                <div id="api-connection-bar" class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width:0%">
                                    <span class="sr-only">procesando...</span>
                                </div>
                            </div>
                        </div>
                        <div id="api-connection-check-status"></div>
                        <button id="api-connection-check-btn" type="button" class="btn btn-primary float-end">Comprobar Conexión</button>
                    </div>
                </div>
                <div id="api-connection-check-save-btns" class="d-flex p-0">
                    <div class="col-md-12 col-xs-12">

                    </div>
                </div>
            </div>

            <div class="form-wrap mt-5">
                <h2><b>Configuración de relación entre WooCommerce y Api Custom Plugin</b></h2>
                <hr>
                <div class="form-field form-required term-name-wrap">
                    <label for="tag-name"><b>Stock Almacén Api Custom Plugin</b></label>
                    <select class="form-control" id="CGAPI_STOCK" styel="width:100%">
                        <?php
                        if (count($data->db->warehouses) <= 0) :
                            ?>
                            <option value="" selected disabled>- sin registro de almacenes -</option>
                            <?php
                        else :
                            ?>
                            <option value="" selected disabled>- selecciona almacén -</option>
                            <?php
                            foreach ($data->db->warehouses as $v) :
                                ?>
                                <option value="<?= $v->IdAlmacen; ?>" <?= ($v->IdAlmacen == $data->db->api->warehouse ? 'selected' : ''); ?>><?= $v->Descripcion; ?></option>
                                <?php
                            endforeach;
                        endif;
                        ?>
                    </select>
                    <p id="CGAPI_STOCK_alert">Almacén de aplicación Api Custom Plugin de donde se tomará el stock de los productos que se publiquen en WooCommerce.</p>
                </div>
                <div class="form-field form-required term-name-wrap">
                    <label for="tag-name"><b>Referencia WooCommerce</b></label>
                    <select class="form-control" id="CGAPI_WP_REF">
                        <option value="" disabled selected>- referencia en WooCommerce -</option>
                        <option value="sku" <?= ($data->db->api->wp_ref == 'sku' ? 'selected' : ''); ?>>SKU</option>
                    </select>
                    <p id="CGAPI_WP_REF_alert">Campo de productos para relación de WooCommerce con aplicación Api Custom Plugin.</p>
                </div>
                <div class="form-field form-required term-name-wrap">
                    <label for="tag-name"><b>Referencia Api Custom Plugin</b></label>
                    <select class="form-control" id="CGAPI_CG_REF">
                        <option value="" disabled selected>- referencia en Api Custom Plugin -</option>
                        <option value="Codigo" <?= ($data->db->api->cg_ref == 'Codigo' ? 'selected' : ''); ?>>Codigo</option>
                        <option value="ReferenciaProveedor" <?= ($data->db->api->cg_ref == 'ReferenciaProveedor' ? 'selected' : ''); ?>>Referencia Proveedor</option>
                    </select>
                    <p id="CGAPI_CG_REF_alert">Campo de productos Api Custom Plugin para relación en la conexión.</p>
                </div>
                <div class="form-field form-required term-name-wrap">
                    <label for="tag-name"><b>Contabilizar Ajuste Manual</b></label>
                    <select class="form-control" id="CGAPI_WP_ADJ">
                        <?php $data->db->api->wp_adj = empty($data->db->api->wp_adj) ? 0 : 1; ?>
                        <option value="0" <?= ($data->db->api->wp_adj == 0 ? 'selected' : ''); ?>>No informar ajustes manuales (recomendable)</option>
                        <option value="1" <?= ($data->db->api->wp_adj == 1 ? 'selected' : ''); ?>>Informar ajustes manuales</option>
                    </select>
                    <p>Cada vez que ajuste manualmente el stock de cada producto en WooCommerce se notificará o no, la diferencia al almacén de Api Custom Plugin.</p>
                </div>
                <div class="form-group clearfix clear d-flex p-0">
                    <div class="col-md-8 col-xs-12"></div>
                    <div class="col-md-4 col-xs-12" id="api-connection-config-btns-wrapper">
                        <button id="api-connection-config-btn" type="button" class="btn btn-primary float-end">Guardar</button>
                    </div>
                </div>
            </div><!-- /form-wrap -->

            <div class="form-wrap mt-5">
                <h2><b>Sincronización Stock WooCommerce relacionado a Api Custom Plugin</b></h2>
                <hr>
                <div class="form-field form-required term-name-wrap">
                    <?php
                    $warehouse = !empty($data->db->api->warehouse) ? '' : '(sin almacén seleccionado)';
                    if (! empty($data->db->api->warehouse)) :
                        foreach ($data->db->warehouses as $v) :
                            if ($v->IdAlmacen == $data->db->api->warehouse) $warehouse = $v->Descripcion;
                        endforeach;
                    endif;
                    ?>
                    <label for="tag-name">Las actualizaciones de stock se realizarán desde el almacén: <b><?= $warehouse; ?></b></label>
                </div>
                <div id="api-update-stock-wrapper" class="d-flex p-0">
                    <div class="col-md-12">
                        <div id="api-update-stock-status"></div>
                        <div id="api-update-stock-bar-wrapper" style="display:none">
                            <div class="progress">
                                <div id="api-update-stock-bar" class="progress-bar" role="progressbar" aria-valuenow="1" aria-valuemin="0" aria-valuemax="100" style="width:0%">
                                    <span class="sr-only">procesando...</span>
                                </div>
                            </div>
                        </div>
                        <button id="api-update-stock-btn" type="button" class="btn btn-primary float-end">Actualizar Stock</button>
                    </div>
                </div>
            </div><!-- /form-wrap -->

        </div><!-- /col-wrap -->
    </div><!-- /col-right -->

</div>