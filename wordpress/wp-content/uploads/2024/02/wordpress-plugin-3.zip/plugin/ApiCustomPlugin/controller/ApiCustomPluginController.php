<?php

namespace ApiCustomPlugin\Controller;

/**
 * ApiCustomPlugin
 *
 * @package ApiCustomPlugin
 * @author Pablo Ripoll
 */

use ApiCustomPlugin\Support\Log;
use ApiCustomPlugin\Model\ApiApiCustomPluginModel;

class ApiApiCustomPluginController
{
    /**
	 * Static access to self methods
	 * @return object
	 */
    public static function Action() {
		return new self;
	}

    public function getArticulo($data)
    {
        $wp_key = $data->api['wp_ref'];
        $cg_key = $data->api['cg_ref'];
        $value  = $data->product[$wp_key];
        $condition = $cg_key."='$value'";

        $api = new \stdClass;
        $api->name     = $data->api['name'];
        $api->endpoint = $data->api['endpoint'].'/conceptos/'.base64_encode($condition);
        $api->key      = $data->api['key'];
        $api->user     = $data->api['user'];

        $producto = json_decode(ApiApiCustomPluginModel::Api()->GET($api));

        return $producto[0];
    }

    public function getAlmacenes($data)
    {
        $api = new \stdClass;
        $api->name     = $data->api['name'];
        $api->endpoint = $data->api['endpoint'].'/almacen';
        $api->key      = $data->api['key'];
        $api->user     = $data->api['user'];
        $almacenes = json_decode(ApiApiCustomPluginModel::Api()->GET($api));

        return $almacenes;
    }

    public function getStockArticulo($data, $id_tarifa, $id_almacen)
    {
        $condition = "IdTarifa='$id_tarifa' AND IdAlmacen='$id_almacen'";

        $api = new \stdClass;
        $api->name     = $data->api['name'];
        $api->endpoint = $data->api['endpoint'].'/almacen_stock/'.base64_encode($condition);
        $api->key      = $data->api['key'];
        $api->user     = $data->api['user'];
        $stockProducto = json_decode(ApiApiCustomPluginModel::Api()->GET($api));

        return $stockProducto[0];
    }

    public function updateStockArticulo($data, $body, $idProductStock)
    {
        $api = new \stdClass;
        $api->name      = $data->api['name'];
        $api->endpoint  = $data->api['endpoint'].'/almacen_stock/'.$idProductStock;
        $api->key       = $data->api['key'];
        $api->user      = $data->api['user'];
        $api->body      = json_encode($body);
        $httpResponse   = json_decode(ApiApiCustomPluginModel::Api()->PUT($api));

        return $httpResponse;
    }

    public function updateStockMovimiento($data, $body)
    {
        $api = new \stdClass;
        $api->name      = $data->api['name'];
        $api->endpoint  = $data->api['endpoint'].'/stock_movimientos';
        $api->key       = $data->api['key'];
        $api->user      = $data->api['user'];
        $api->body      = json_encode($body);
        $stockMovimiento= json_decode(ApiApiCustomPluginModel::Api()->POST($api));

        return $stockMovimiento;
    }
}