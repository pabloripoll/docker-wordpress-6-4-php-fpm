<div class="col-wrap mt-5">

    <div id="col-left">
        <div class="col-wrap">
            <div class="form-wrap">
                <?php
                $listDescText  = '<b>Página <font class="cloud-gestion-history-page">'.$data->db->page.'</font></b>';
                $listDescText .= ' de '.$data->db->pages;
                $listDescText .= $data->db->pages == 1 ? ' página' : ' páginas';
                ?>
                <p>Listado: <?= $listDescText; ?>.</p>
            </div>
        </div>
    </div><!-- /col-left -->

    <div id="col-right">
        <div class="col-wrap">
            <div class="form-wrap">
                <ul class="pagination float-end mb-2">
                    <li class="page-item"><a class="page-link" href="javascript:ApiCustomPluginHistoryPrev()">Anterior</a></li>
                    <li class="page-item"><a class="page-link" href="javascript:ApiCustomPluginHistoryNext()">Siguiente</a></li>
                </ul>
            </div>
        </div>
    </div><!-- /col-right -->

    <table class="widefat attributes-table wp-list-table ui-sortable" style="width:100%">
        <thead>
            <tr>
                <th style="width:10%">Fecha</th>
                <th style="width:10%">Acción</th>
                <th style="width:25%">Descripcion</th>
                <th style="width:10%;text-align:center;">Stock</th>
                <th style="width:10%;text-align:center;">Cantidad</th>
                <th style="width:10%;text-align:center;">Nuevo Stock</th>
                <th style="width:25%">Producto</th>
            </tr>
        </thead>
        <tbody id="cloud-gestion-history-table-body">
            <?php
            $i = 0;
            foreach ($data->db->registers as $row) :
                $i++;
                $rowclass = $i % 2 != 0 ? 'alternate' : '';
                ?>
                <tr class="<?= $rowclass; ?>">
                    <td><?= $row->updated_at; ?></td>
                    <td><?= $row->action; ?></td>
                    <td><?= $row->description; ?></td>
                    <?php
                    if ($row->quantity == 0) :
                        ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <?php
                    else :
                        ?>
                        <td align="right"><?= $row->stock; ?></td>
                        <td align="right"><?= $row->quantity; ?></td>
                        <td align="right"><?= $row->stock_update; ?></td>
                        <td>
                            <a href="/wp-admin/post.php?post=<?= $row->id_product; ?>&action=edit" target="_blank" title="abrir <?= $row->name; ?> en nueva pestaña"><?php echo $row->name; ?></a>
                        </td>
                        <?php
                    endif;
                    ?>
                </tr>
                <?php
            endforeach;
            ?>
        </tbody>
    </table>

    <div id="col-left">
        <div class="col-wrap">
            <div class="form-wrap mt-2">
                <p>Listado: <?= $listDescText; ?>.</p>
            </div>
        </div>
    </div><!-- /col-left -->

    <div id="col-right">
        <div class="col-wrap">
            <div class="form-wrap">
                <ul class="pagination float-end mt-2">
                    <li class="page-item"><a class="page-link" href="javascript:ApiCustomPluginHistoryPrev()">Anterior</a></li>
                    <li class="page-item"><a class="page-link" href="javascript:ApiCustomPluginHistoryNext()">Siguiente</a></li>
                </ul>
            </div>
        </div>
    </div><!-- /col-right -->

</div>