<?php

namespace ApiCustomPlugin\Model;

/**
 * ApiCustomPlugin
 *
 * @package ApiCustomPlugin
 * @author Pablo Ripoll
 */

class SetupApiCustomPluginModel
{
    /**
	 * Table prefix
	 *
	 * @var string
	 */
	private $prefix = 'acp_';

    /**
	 * Install access
	 *
	 * @var string
	 */
	public static function install()
    {
        $db = new self;
        $db->createTableConnection();
        $db->createTableWarehouses();
        $db->createTableHistory();
    }

    public function createTableConnection()
    {
        global $wpdb;

        $sql = [];
        $tableName = $this->prefix.'connection';
        $charsetCollate = $wpdb->get_charset_collate();

        $sql[] = "CREATE TABLE IF NOT EXISTS `$tableName` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(64) NOT NULL,
            `endpoint` VARCHAR(255) NOT NULL,
            `apikey` VARCHAR(64) NOT NULL,
            `user` INT(11) NOT NULL DEFAULT \"0\",
            `warehouse` INT(11) NOT NULL DEFAULT \"0\",
            `wp_ref` VARCHAR(32) NOT NULL,
            `cg_ref` VARCHAR(32) NOT NULL,
            `wp_adj` INT(1) NOT NULL,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) $charsetCollate";
        $sql[] = "INSERT INTO `$tableName` (`name`, `endpoint`, `apikey`, `user`, `updated_at`) VALUES ('', '', '', '', '".date('Y-m-d H:i:s')."');";

        foreach ($sql as $statement) !empty($statement) ? $wpdb->query($statement) : null;
    }

    public function createTableWarehouses()
    {
        global $wpdb;

        $sql = [];
        $tableName = $this->prefix.'warehouses';
        $charsetCollate = $wpdb->get_charset_collate();

        $sql[] ="CREATE TABLE IF NOT EXISTS `$tableName` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `IdAlmacen` INT(11) NOT NULL DEFAULT \"0\",
            `Descripcion` VARCHAR(32) NOT NULL,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) $charsetCollate";

        foreach ($sql as $statement) !empty($statement) ? $wpdb->query($statement) : null;
    }

    public function createTableHistory()
    {
        global $wpdb;

        $sql = [];
        $tableName = $this->prefix.'history';
        $charsetCollate = $wpdb->get_charset_collate();

        $sql[] = "CREATE TABLE IF NOT EXISTS `$tableName` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `reference` VARCHAR(32) NOT NULL,
            `action` VARCHAR(32) NOT NULL,
            `description` VARCHAR(128) NOT NULL,
            `id_product` INT(11) NOT NULL,
            `name` VARCHAR(32) NOT NULL,
            `stock` VARCHAR(32) NOT NULL,
            `quantity` VARCHAR(32) NOT NULL,
            `stock_update` VARCHAR(32) NOT NULL,
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) $charsetCollate";
        $sql[] = "INSERT INTO `$tableName` (`reference`, `action`, `description`, `updated_at`) VALUES ('module', 'instalacion', 'Se realiz&oacute; instalaci&oacute;n del modulo', '".date('Y-m-d H:i:s')."');";
        $sql[] = "INSERT INTO `$tableName` (`reference`, `action`, `description`, `updated_at`) VALUES ('module', 'instalacion', 'Recuerde revisar conexi&oacute;n y guardar configuraciones', '".date('Y-m-d H:i:s')."');";

        foreach ($sql as $statement) !empty($statement) ? $wpdb->query($statement) : null;
    }

    /**
	 * Uninstall access
	 *
	 * @var string
	 */
	public static function uninstall()
    {
        $db = new self;
        $db->deleteTableConnection();
        $db->deleteTableWarehouses();
        $db->deleteTableHistory();
    }

    public function deleteTableConnection()
    {
        global $wpdb;

        $sql = [];
        $tableName = $this->prefix.'connection';
        $sql[] = "DROP TABLE IF EXISTS `$tableName`";

        foreach ($sql as $statement) ! empty($statement) ? $wpdb->query($statement) : null;
    }

    public function deleteTableWarehouses()
    {
        global $wpdb;

        $sql = [];
        $tableName = $this->prefix.'warehouses';
        $sql[] = "DROP TABLE IF EXISTS `$tableName`";

        foreach ($sql as $statement) !empty($statement) ? $wpdb->query($statement) : null;
    }

    public function deleteTableHistory()
    {
        global $wpdb;

        $sql = [];
        $tableName = $this->prefix.'history';
        $sql[] = "DROP TABLE IF EXISTS `$tableName`";

        foreach ($sql as $statement) !empty($statement) ? $wpdb->query($statement) : null;
    }

}
