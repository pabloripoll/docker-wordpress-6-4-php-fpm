<?php

namespace ApiCustomPlugin\Config;

/**
 * ApiCustomPlugin
 *
 * @package ApiCustomPlugin
 * @author Pablo Ripoll
 */

use ApiCustomPlugin\Support\Log;
use ApiCustomPlugin\Controller\ApiApiCustomPluginController;
use ApiCustomPlugin\Controller\AdminApiCustomPluginController;
use ApiCustomPlugin\Model\AdminApiCustomPluginModel;

/**
 * Main class, bootstraps the plugin
 */
class ApiCustomPlugin
{
	/**
	 * The plugin file
	 *
	 * @var string
	 */
	public $file;

	/**
	 * The plugin directory
	 *
	 * @var string
	 */
	public $dir;

	/**
	 * The plugin url
	 *
	 * @var string
	 */
	public $url;

	/**
	 * Version
	 *
	 * @var string
	 */
	public $version = '1.0.0';

	/**
	 * Admin (only set in admin)
	 *
	 * @var AdminApiCustomPluginController
	 */
	public $admin;

	/**
	 * Bootstrap
	 *
	 * @param string file path and name
	 */
	public function __construct($file)
	{
		$this->file = $file;
		$this->dir  = plugin_dir_path($file);
		$this->slug = 'ApiCustomPlugin';
		$this->url	= str_replace('config/', '', plugins_url('/', __FILE__));

		if (is_admin()) {
			$this->admin = new AdminApiCustomPluginController($this);
		}
	}

	/**
	 * WooCommerce stock adjust inform
	 *
	 * Get Config to informe Api Custom Plugin API
	 *
	 * @return array
	 */
	public static function getWooCommerceStockAdjust()
    {
        $api = AdminApiCustomPluginModel::DB()->getApiData();
		return $api->wp_adj;
	}

	/**
	 * WooCommerce - stock update from order
	 *
	 * @param object $product
	 * @param string $action (increase/decrease)
	 *
	 */
	public static function wcStockUpdateFromOrder($order, $action)
	{
		if ($action == 'increase') {
			$order = new \WC_Order(intval($order));
		}
		//$orderData = $order->get_data();
		$items = $order->get_items();
		foreach ($items as $order) {
			$deltaQuantity = $action == 'increase' ? $order['quantity'] : -$order['quantity'];
			$productData = $order->get_product()->get_data();
			$product = [
				'id_product'	=> $order['product_id'],
				'name'			=> $order['name'],
				'sku'			=> $productData['sku'],
				'quantity'		=> $productData['stock_quantity'], // Stock con cambio efectuado
				'delta_quantity'=> $deltaQuantity, // cantidad que se ha incrementado o reducido
				'origin'		=> 'order'
			];
			self::updateApiCustomPluginStock($product);
		}
	}

	/**
	 * WooCommerce - stock update from product edition
	 *
	 * @param object $product
	 *
	 */
	public static function wcStockUpdateFromProduct($product)
	{
		$wc_inform = self::getWooCommerceStockAdjust();
		if ($wc_inform == 1) {
			$itemChange = $product->get_changes();
			if (count($itemChange) > 0 && isset($itemChange['stock_quantity'])) {
				$productData  = $product->get_data();
				if ($itemChange['stock_quantity'] < $productData['stock_quantity']) {
					$deltaQuantity = $itemChange['stock_quantity'] - $productData['stock_quantity'];
				} else {
					$deltaQuantity = -($productData['stock_quantity'] - $itemChange['stock_quantity']);
				}
				$product = [
					'id_product'	=> $productData['id'],
					'name'			=> $productData['name'],
					'sku'			=> $productData['sku'],
					'quantity'		=> $itemChange['stock_quantity'], // Stock con cambio efectuado
					'delta_quantity'=> $deltaQuantity, // cantidad que se ha incrementado o reducido
					'origin'		=> 'manually'
				];
				self::updateApiCustomPluginStock($product);
			}
		}
	}

	/**
	 * Api Custom Plugin - stock update
	 * this method is called whenever product stock has changed
	 *
	 * @param object $product
	 *
	 */
	private static function updateApiCustomPluginStock($product)
	{
		$data = new \stdClass;
		$api = AdminApiCustomPluginModel::DB()->getApiData();

		if (
			empty($api->endpoint) ||
			empty($api->apikey) ||
			empty($api->user) ||
			empty($api->wp_ref) ||
			empty($api->cg_ref)
		) {
			Log::Debug('Api Custom Plugin api data incomplete');
			die;
		}

        $data->api = [
            'name'      => $api->name,
            'endpoint'  => $api->endpoint,
            'key'       => $api->apikey,
            'user'      => $api->user,
            'wp_ref'    => $api->wp_ref,
            'cg_ref'    => $api->cg_ref,
        ];

		$data->product = [
            'id_product'	=> $product['id_product'],
            'name'			=> $product['name'],
            'sku'			=> $product['sku'],
            'quantity'		=> $product['quantity'],
            'delta_quantity'=> $product['delta_quantity'],
			'origin'		=> $product['origin']
        ];

		// Extraer IdTarifa desde ApiCustomPlugin
        $concepto = ApiApiCustomPluginController::Action()->getArticulo($data);
        if (!empty($concepto)) {
			$id_tarifa = $concepto->IdTarifa;

			// Almacen guardado como stock de referencia en ApiCustomPlugin
			$id_almacen = $api->warehouse;

			// Stock de producto en aplicación ApiCustomPlugin
			$stockProducto = ApiApiCustomPluginController::Action()->getStockArticulo($data, $id_tarifa, $id_almacen);
			if ($stockProducto) {
				$idProductStock = $stockProducto->IdAlmacenStock;
				$apiQuantity = $stockProducto->Stock;

				$deltaQuantity = $data->product['delta_quantity'];
				if ($deltaQuantity < 0) {
					$action = 'rest';
					$actionText = 'Descuento de stock en ApiCustomPlugin';
					$newApiQuantity = $apiQuantity - abs($deltaQuantity);
				} else {
					$action = 'sum';
					$actionText = 'Reincorporaci&oacute;n de stock en ApiCustomPlugin';
					$newApiQuantity = $apiQuantity + abs($deltaQuantity);
				}

				// Actualizar stock en Api Custom Plugin
				$body = ['Stock' => $newApiQuantity];
				$response = ApiApiCustomPluginController::Action()->updateStockArticulo($data, $body, $idProductStock);
				if ($response == '200') {

					// Informar movimiento de stock en Api Custom Plugin
					$actionTextCG = str_replace('ApiCustomPlugin', 'WooCommerce', $actionText);

					$body = [
						'IdAlmacen'     => $id_almacen,
						'IdProducto'    => $id_tarifa,
						'Fecha'         => date('Y-m-d'),
						'Hora'          => date('Y-m-d H:i:s'),
						'Salida'        => $action == 'sum' ? 0 : abs($deltaQuantity),
						'Entrada'       => $action == 'sum' ? abs($deltaQuantity) : 0,
						'Existencias'   => $newApiQuantity,
						'Observaciones' => $actionTextCG,
						'Documento'     => 'WooCommerce',
						'IdDocumento'   => 0,
						'Tipo'          => $action == 'sum' ? 'Entrada' : 'Salida'
					];
					$response = ApiApiCustomPluginController::Action()->updateStockMovimiento($data, $body);

					$history = new \stdClass;
					$history->reference		= 'product';
					$history->action		= 'stock';
					$history->description	= $actionText;
					$history->id_product    = $data->product['id_product'];
					$history->stock         = $apiQuantity;
					$history->quantity      = $action == 'sum' ? abs($deltaQuantity) : '-'.abs($deltaQuantity);
					$history->stock_update  = $newApiQuantity;
					$history->name          = $data->product['name'];
					AdminApiCustomPluginModel::DB()->setActionHistory($history);

				} else {
					Log::Debug('Error en config::updateApiCustomPluginStock()'); // some error display
					Log::Debug($response); // some error display
				}
			}
		}
	}

	/**
	 * Api Custom Plugin - stock update
	 * this method is called whenever product stock has changed
	 *
	 * @param object $product
	 *
	 */
	public static function updateWooCommerceStock($product)
	{
		$actionText = 'Actualizaci&oacute;n de stock de WooCommerce';
		$history = new \stdClass;
		$history->reference		= 'product';
		$history->action		= 'stock';
		$history->description	= $actionText;
		$history->id_product    = $product['id'];
		$history->stock         = 's/i';
		$history->quantity      = 'n/c';
		$history->stock_update  = $product['stock_quantity'];
		$history->name          = $product['name'];
		AdminApiCustomPluginModel::DB()->setActionHistory($history);
	}

	/**
	 * Initialize
	 */
	public function init()
	{
		//load_plugin_textdomain('woocommerce_stock_sync', false, dirname(plugin_basename($this->file)) . '/languages/');
	}

}
